package GUIStuff;

import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedList;
import javax.swing.*;

public class FalconDankPlot extends JPanel implements ClipboardOwner {
	private static final long serialVersionUID = 3205256608145459434L;
	private double upperXtic = 54.33333;
	private double upperYtic = 27;
	private double yMax = 27;
	private double xMax = 54.33333;
	protected static int count = 0;
	private double width, height, xScale, yScale;
	private double yTickYMax = 0, yTickYMin = 0;
	private double x1vert = 0;
	Rectangle rect;
	public JFrame g;
	ArrayList<Double> xInputs = new ArrayList<Double>();
	ArrayList<Double> yInputs = new ArrayList<Double>();
	public int numPathPoints = 2;
	public static MPGen2D selectedPath;

	JPopupMenu menu = new JPopupMenu("Popup");
	
	public static FalconDankPlot fig;


	//Link List to hold all different plots on one graph.
	public LinkedList<xyNode> link; 

	/**
	 * Constructor which Plots only Y-axis data.
	 * @param yData is a array of doubles representing the Y-axis values of the data to be plotted.
	 */
	public FalconDankPlot(double[] yData) {
		this(null, yData, Color.red);
	}

	public FalconDankPlot(double[] yData,Color lineColor, Color marker) {
		this(null, yData, lineColor, marker, null, null);
	}

	/**
	 * Constructor which Plots chart based on provided x and y data. X and Y arrays must be of the same length.
	 * @param xData is an array of doubles representing the X-axis values of the data to be plotted.
	 * @param yData is an array of double representing the Y-axis values of the data to be plotted.
	 */
	public FalconDankPlot(double[] xData, double[] yData) {
		this(xData, yData, Color.red, null, null, null);
	}

	/**
	 * Constructor which Plots chart based on provided x and y axis data. 
	 * @param data is a 2D array of doubles of size Nx2 or 2xN. The plot assumes X is the first dimension, and y data
	 * is the second dimension.
	 */
	public FalconDankPlot(double[][] data) {
		this(getXVector(data), getYVector(data), Color.red, null, null, null);
	}

	/**
	 * Constructor which plots charts based on provided x and y axis data in a single two dimensional array.
	 * @param data is a 2D array of doubles of size Nx2 or 2xN. The plot assumes X is the first dimension, and y data
	 * is the second dimension.
	 * @param lineColor is the color the user wishes to be displayed for the line connecting each datapoint
	 * @param markerColor is the color the user which to be used for the data point. Make this null if the user wishes to
	 * not have datapoint markers.
	 */
	public FalconDankPlot(double[][] data, Color lineColor, Color markerColor) {
		this(getXVector(data), getYVector(data), lineColor, markerColor, null, null);
	}

	/**
	 * Constructor which plots charts based on provided x and y axis data provided as separate arrays. The user can also specify the color of the adjoining line.
	 * Data markers are not displayed.
	 * @param xData is an array of doubles representing the X-axis values of the data to be plotted.
	 * @param yData is an array of double representing the Y-axis values of the data to be plotted.
	 * @param lineColor is the color the user wishes to be displayed for the line connecting each datapoint
	 */
	public FalconDankPlot(double[] xData, double[] yData, Color lineColor) {
		this(xData, yData, lineColor, null, null, null);
	}

	public FalconDankPlot(double[][] data, Color lineColor) {
		this(getXVector(data), getYVector(data), lineColor, null, null, null);
	}

	/**
	 * Constructor which plots charts based on selected x and y axis data. The user 
	 * must specify the number of points in the outlined path. For example if you select (0, 0), (2, 0), (4, 0),
	 * numPoints must be 3.
	 * @param numPoints is the number of points in the selected path
	 * @param dragMode has to be implemented still so dw about it
	 */
	public FalconDankPlot(int numPoints, boolean dragMode) {
		this(null, null, null, null, numPoints, dragMode);
	}

	public FalconDankPlot(int i) {
		this(null, null, null, null, i, null);
	}

	/**
	 * Constructor which plots charts based on provided x and y axis data, provided as separate arrays. The user 
	 * can also specify the color of the adjoining line and the color of the datapoint maker.
	 * @param xData is an array of doubles representing the X-axis values of the data to be plotted.
	 * @param yData is an array of double representing the Y-axis values of the data to be plotted.
	 * @param lineColor is the color the user wishes to be displayed for the line connecting each datapoint
	 * @param markerColor is the color the user which to be used for the data point. Make this null if the user wishes to
	 * not have datapoint markers.
	 */
	public FalconDankPlot(double[] xData, double[] yData, Color lineColor, Color markerColor, Integer points, Boolean drag) {
		upperXtic = -Double.MAX_VALUE;
		upperYtic = -Double.MAX_VALUE;

		link = new LinkedList<xyNode>();
		link.add(new xyNode(new double[]{0}, new double[]{0}, false, null, null));
		
		if(yData != null) addData(xData, yData, lineColor, markerColor);

		count++;

		g = new JFrame("Figure " + count);
		g.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		g.add(this);
		g.setSize(1280,720);
		g.setLocationByPlatform(true);
		g.setVisible(true);

		menu(g,this);
	}

	/**
	 * Main method which paints the panel and shows the figure.
	 * 
	 */
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D)g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		width = getWidth();
		height = getHeight();

		// Draw X and Y lines axis.
		Line2D.Double yaxis = new Line2D.Double(30, 10, 30, height - 30);
		Line2D.Double xaxis = new Line2D.Double(30, height - 30, width, height - 30);
		g2.draw(yaxis);
		g2.draw(xaxis);

		//draw ticks
		drawYTickRange(g2, yaxis, yMax);
		drawXTickRange(g2, xaxis, xMax);

		//plot field
		plotFieldBorder(g2);
		rect = new Rectangle((int)yaxis.getX1(), (int)yaxis.getY1(), (int)(x1vert - xaxis.getX1()), (int)(yaxis.getY2() - yaxis.getY1()));
		g2.setColor(Color.black);
		g2.draw(rect);

		xScale = (double)(rect.getWidth())/(54.3333333);
		yScale = (double)(rect.getHeight())/(27.0);

		plotFieldElements(g2);

		//plot data
		plot(g2);
	}

	/**
	 * Adds a plot to an existing figure.  
	 * @param yData is a array of doubles representing the Y-axis values of the data to be plotted.
	 * @param color is the color the user wishes to be displayed for the line connecting each datapoint
	 */
	public void addData(double[] y, Color lineColor) {
		addData(y, lineColor, null);
	}

	public void addData(double[] y, Color lineColor, Color marker) {
		//cant add y only data unless all other data is y only data
		for(xyNode data: link)
			if(data.x != null)
				throw new Error ("All previous chart series need to have only Y data arrays");

		addData(null,y,lineColor, marker);
	}

	public void addData(double[] x, double[] y, Color lineColor) {
		addData(x,y,lineColor,null);
	}


	public void addData(double[][] data, Color lineColor) {
		addData(getXVector(data),getYVector(data),lineColor,null);
	}

	public void addData(double[][] data, Color lineColor, Color marker) {
		addData(getXVector(data),getYVector(data),lineColor,marker);
	}

	public void addData(double[] x, double[] y, Color lineColor, Color marker) { 	
		xyNode Data = new xyNode();

		//copy y array into node
		Data.y = new double[y.length];
		Data.lineColor = lineColor;

		if(marker == null)
			Data.lineMarker = false;
		else {
			Data.lineMarker = true;
			Data.markerColor = marker;
		}
		for(int i=0; i<y.length; i++)
			Data.y[i] = y[i];

		//if X is not null, copy x
		if(x != null) {
			//cant add x, and y data unless all other data has x and y data
			for(xyNode data: link)
				if(data.x == null)
					throw new Error ("All previous chart series need to have both X and Y data arrays");

			if(x.length != y.length)
				throw new Error("X dimension must match Y dimension");

			Data.x = new double[x.length];

			for(int i = 0; i < x.length; i++)
				Data.x[i] = x[i];
		}
		link.add(Data);
	}

	private void plot(Graphics2D g2) {
		int w = super.getWidth();
		int h = super.getHeight();
		Color tempC = g2.getColor();

		//loop through list and plot each
		for(int i=0; i<link.size(); i++) {
			// Draw lines.
			double xScale = (double)(w - 2*30)/(upperXtic);
			double yScale = (double)(h - 2*30)/(upperYtic);

			for(int j = 0; j < link.get(i).y.length-1; j++) {
				double x1;
				double x2;

				if(link.get(i).x==null) {
					x1 = 30 + j*xScale;
					x2 = 30 + (j+1)*xScale;
				} else {
					x1 = 30 + xScale*link.get(i).x[j];
					x2 = 30 + xScale*link.get(i).x[j+1];
				}

				double y1 = h - 30 - yScale*link.get(i).y[j];
				double y2 = h - 30 - yScale*link.get(i).y[j+1];
				g2.setPaint(link.get(i).lineColor);
				g2.draw(new Line2D.Double(x1, y1, x2, y2));

				if(link.get(i).lineMarker) {
					g2.setPaint(link.get(i).markerColor);
					g2.fill(new Ellipse2D.Double(x1-2, y1-2, 4, 4));
					g2.fill(new Ellipse2D.Double(x2-2, y2-2, 4, 4));
				}
			}
		}
		g2.setColor(tempC);
	}

	private void plotFieldElements(Graphics2D g2) {
		ArrayList<double[][]> elements = new ArrayList<double[][]>();
		double leftAutoLine[][] = new double[][] {
			{7.775, 0},
			{7.775, 27.0},
		};
		double rightAutoLine[][] = new double[][] {
			{46.55833, 0},
			{46.55833, 27.0},
		};
		double leftAirship[][] = new double[][] {
			{15.44166, 11.79},//3.42 ft
			{15.44166, 15.21},//5.9241666666666666666666666666666
			{12.47926, 16.90583},
			{9.517493, 15.21},//9.5174933333333333333333333333333
			{7.788327, 16.185},
			{9.517493, 15.21},
			{9.517493, 11.79},//2.9625 , 1.695833333
			{7.788327, 10.815},
			{9.517493, 11.79},
			{12.47926, 10.09417},//1.729166, 0.975
			{15.44166, 11.79},
		};
		double rightAirship[][] = new double[][] {
			{38.89167, 11.79},//3.42 ft
			{38.89167, 15.21},//5.9241666666666666666666666666666
			{41.85407, 16.90583},
			{44.81584, 15.21},//9.5174933333333333333333333333333
			{46.545, 16.185},
			{44.81584, 15.21},
			{44.81584, 11.79},//2.9625 , 1.695833333
			{46.545, 10.815},
			{44.81584, 11.79},
			{41.85407, 10.09417},//1.7291666, 0.975 
			{38.89167, 11.79},
		};
		double leftBoiler[][] = new double[][] {
			{},
			{},
		};
		double rightBoiler[][] = new double[][] {
			{},
			{},
		};
		elements.add(leftAutoLine);
		elements.add(rightAutoLine);
		elements.add(leftAirship);
		elements.add(rightAirship);
		elements.add(leftBoiler);
		elements.add(rightBoiler);
		int h = super.getHeight();

		for(int z = 0; z < elements.size(); z++)
			for(int i = 0; i < elements.get(z).length - 1; i++)
				for(int j = 0; j < elements.get(z)[0].length - 1; j++) {
					double x1 = 30 + xScale*elements.get(z)[i][j];
					double x2 = 30 + xScale*elements.get(z)[i + 1][j];
					double y1 = h - 30 - yScale*elements.get(z)[i][j + 1];
					double y2 = h - 30 - yScale*elements.get(z)[i + 1][j + 1];

					g2.setPaint(Color.black);
					g2.draw(new Line2D.Double(x1, y1, x2, y2));
				}
	}

	private void drawYTickRange(Graphics2D g2, Line2D yaxis, double Max) {
		if(Max<0)
			upperYtic = Math.floor(Max);
		else
			upperYtic = Math.ceil(Max);

		double x0 = yaxis.getX1();
		double y0 = yaxis.getY1();
		double xf = yaxis.getX2();
		double yf = yaxis.getY2();

		//calculate stepsize between ticks and length of Y axis using distance formula
		double distance = Math.sqrt(Math.pow((xf-x0), 2)+Math.pow((yf-y0), 2)) / upperYtic;

		double upper = upperYtic;
		yTickYMax = y0;
		double newY = 0;
		for(int i = 0; i<=upperYtic; i++) {
			newY = y0;
			//calculate width of number for proper drawing
			String number = new DecimalFormat("#.#").format(upper);
			FontMetrics fm = getFontMetrics(getFont());
			int width = fm.stringWidth(number);

			g2.draw(new Line2D.Double(x0,newY, x0-10,newY));
			g2.drawString(number, (float)x0-15-width, (float)newY+5); 

			//add grid lines to chart
			if(i!=upperYtic) {
				Stroke tempS = g2.getStroke();
				Color tempC = g2.getColor();

				g2.setColor(Color.lightGray);
				g2.setStroke(new BasicStroke(
						1f, 
						BasicStroke.CAP_ROUND, 
						BasicStroke.JOIN_ROUND, 
						1f, 
						new float[] {5f}, 
						0f));

				g2.draw(new Line2D.Double(30, newY, getWidth(), newY));

				g2.setColor(tempC);
				g2.setStroke(tempS);
			}
			upper -= 1;
			y0 = newY + distance;
		}
		yTickYMin = newY;
	}

	private void drawXTickRange(Graphics2D g2, Line2D xaxis, double Max) {
		drawXTickRange(g2, xaxis, Max, 1);
	}

	private void drawXTickRange(Graphics2D g2, Line2D xaxis, double Max, double skip) {
		if(Max<0)
			upperXtic = Math.floor(Max);
		else
			upperXtic = Math.ceil(Max);

		double x0 = xaxis.getX1();
		double y0 = xaxis.getY1();
		double xf = xaxis.getX2();
		double yf = xaxis.getY2();

		//calculate stepsize between ticks and length of Y axis using distance formula
		double distance = Math.sqrt(Math.pow((xf-x0), 2)+Math.pow((yf-y0), 2)) / upperXtic;

		double lower = 0;
		for(int i = 0; i <= upperXtic; i++) {
			double newX = x0;

			//calculate width of number for proper drawing
			String number = new DecimalFormat("#.#").format(lower);
			FontMetrics fm = getFontMetrics( getFont() );
			int width = fm.stringWidth(number);

			g2.draw(new Line2D.Double(newX,yf, newX,yf+10));

			//dont label every x tic to prevent clutter
			if(i%skip==0)
				g2.drawString(number, (float)(newX-(width/2.0)), (float)yf+25); 

			//add grid lines to chart
			if(i!=0) {
				Stroke tempS = g2.getStroke();
				Color tempC = g2.getColor();

				g2.setColor(Color.lightGray);
				g2.setStroke(new BasicStroke(
						1f, 
						BasicStroke.CAP_ROUND, 
						BasicStroke.JOIN_ROUND, 
						1f, 
						new float[] {5f}, 
						0f));

				g2.draw(new Line2D.Double(newX, yTickYMax, newX, getHeight()-(getHeight() - yTickYMin)));

				g2.setColor(tempC);
				g2.setStroke(tempS);
			}
			lower += 1;
			x0 = newX + distance;
		}
	}

	private void plotFieldBorder(Graphics2D g2) {
		double[][] dank = new double[][] {
			{54.3333, 0},
			{54.3333, 27.0},
			{0, 27.0},
		};

		int w = super.getWidth();
		int h = super.getHeight();

		// Draw lines.
		double xScale = (double)(w)/(upperXtic);
		double yScale = (double)(h)/(upperYtic);

		for(int i = 0; i < dank.length - 1; i++)
			for(int j = 0; j < dank[0].length - 1; j++) {
				double x1 = xScale*dank[i][j];
				double x2 = xScale*dank[i + 1][j];
				double y1 = h - yScale*dank[i][j + 1];
				double y2 = h - yScale*dank[i + 1][j + 1];

				g2.setPaint(Color.black);
				if(x1 == x2) {
					x1vert = x1;
					g2.draw(new Line2D.Double(x1, y1-(getHeight() - yTickYMin), x2, y2 + yTickYMax));
				} else if(y1 == y2)
					g2.draw(new Line2D.Double(x1, y1 + yTickYMax, x2 + 30, y2 + yTickYMax));
			}
	}

	public void updateData(int series, double[][] data, Color line, Color marker) {
		//add Data to link list
		addData(data, line, marker);

		//copy data from new to old and line styles from list to new list.

		link.get(series).x = link.getLast().x.clone();
		link.get(series).y = link.getLast().y.clone();

		//remove last data
		link.removeLast();
	}

	public static double[] getXVector(double[][] arr) {
		double[] temp = new double[arr.length];
		for(int i = 0; i < temp.length; i++)
			temp[i] = arr[i][0];
		return temp;		
	}

	public static double[] getYVector(double[][] arr) {
		double[] temp = new double[arr.length];
		for(int i = 0; i < temp.length; i++)
			temp[i] = arr[i][1];
		return temp;		
	}

	/**********Class for Linked List************/
	private class xyNode {
		double[] x;
		double[] y;
		boolean lineMarker;
		Color lineColor;
		Color markerColor;

		public xyNode() {
			x = null;
			y = null;
			lineMarker = false;
		}
		
		public xyNode(double[] xArr, double[] yArr, boolean lm, Color l, Color m) {
			x = xArr; y = yArr; lineMarker = lm; lineColor = l;	markerColor = m;
		}
	}

	/****Methods to Support Right Click Menu****/
	@Override
	public void lostOwnership(Clipboard clip, Transferable transferable) {
		//We must keep the object we placed on the system clipboard
		//until this method is called.
	}

	private void menu(JFrame g, final FalconDankPlot p) {
		g.addMouseListener(new PopupTriggerListener());

		JMenuItem item = new JMenuItem("Copy Figure");
		item.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BufferedImage i = new BufferedImage(p.getSize().width, p.getSize().height,BufferedImage.TRANSLUCENT);
				p.setOpaque(false);
				p.paint(i.createGraphics()); 
				TransferableImage trans = new TransferableImage( i );
				Clipboard c = Toolkit.getDefaultToolkit().getSystemClipboard();
				c.setContents( trans, p);
			}
		});
		menu.add(item);

		item = new JMenuItem("Desktop ScreenShot");
		item.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Copy files to clipboard");
				try {
					java.awt.Robot robot = new java.awt.Robot();
					Dimension screenSize  = Toolkit.getDefaultToolkit().getScreenSize();
					Rectangle screen = new Rectangle(screenSize);
					BufferedImage i = robot.createScreenCapture(screen);
					TransferableImage trans = new TransferableImage(i);
					Clipboard c = Toolkit.getDefaultToolkit().getSystemClipboard();
					c.setContents( trans, p);
				} catch (AWTException x) {
					x.printStackTrace();
					System.exit(1);
				}

			}
		});
		menu.add(item);
	}

	class PopupTriggerListener extends MouseAdapter {
		public void mousePressed(MouseEvent ev) {
			if (ev.isPopupTrigger()) {
				menu.show(ev.getComponent(), ev.getX(), ev.getY());
			}
		}

		public void mouseReleased(MouseEvent ev) {
			if (ev.isPopupTrigger()) {
				menu.show(ev.getComponent(), ev.getX(), ev.getY());
			}
		}

		public void mouseClicked(MouseEvent ev) {
			Point p = g.getRootPane().getMousePosition();
			double x = constrainTo((p.getX() - 30), rect.getWidth(), 0.0);
			double y = constrainTo(((height - 30) - p.getY()), rect.getHeight(), 0.0);
			double xField = (double)(x/xScale);
			double yField = (double)(y/yScale);
			if(JOptionPane.showConfirmDialog(ev.getComponent(), "(" + xField + ", " + yField + ")", "Is Point Valid?", JOptionPane.YES_NO_OPTION)
					== JOptionPane.YES_OPTION) {
				System.out.println("Point added");
				xInputs.add(xField);
				yInputs.add(yField);
				link.removeLast();
				selectedPath = new MPGen2D(convertToJewism(xInputs, yInputs), 3.0, 0.02, 3.867227572441874);
				selectedPath.calculate();
				fig.addData(selectedPath.smoothPath, Color.green, Color.green);
				fig.repaint();
			} 
			System.out.println("(" + x + ", " + y + ") " + xField + " " + yField + " " + xScale + " " + yScale + " " + g.getRootPane().getMousePosition());
//			if(xInputs.size() >= numPathPoints)
//				if(JOptionPane.showConfirmDialog(ev.getComponent(), "Are you done adding points?", "Path Validator", JOptionPane.YES_NO_OPTION)
//						== JOptionPane.YES_OPTION) {
//					//TODO Do something with this shit
//				}
		}
	}

	public double[][] convertToJewism(ArrayList<Double> x, ArrayList<Double> y) {
		double[][] temp = new double[x.size()][2];
		for(int i = 0; i < x.size(); i++) {
			temp[i][0] = x.get(i);
			temp[i][1] = y.get(i);
		}
		return temp;
	}

	public double constrainTo(double value, double maxConstrain, double minConstrain) {
		return value == 0.0 ? 0.0 : (Math.signum(value) == 1.0 ? Math.min(value, maxConstrain) : Math.max(value, minConstrain));
	}

	private class TransferableImage implements Transferable {
		Image i;
		public TransferableImage(Image i) {
			this.i = i;
		}

		public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException {
			if (flavor.equals(DataFlavor.imageFlavor) && i != null)	return i;
			else throw new UnsupportedFlavorException(flavor);
		}

		public DataFlavor[] getTransferDataFlavors() {
			DataFlavor[] flavors = new DataFlavor[1];
			flavors[0] = DataFlavor.imageFlavor;
			return flavors;
		}

		public boolean isDataFlavorSupported(DataFlavor flavor) {
			DataFlavor[] flavors = getTransferDataFlavors();
			for (int i = 0; i < flavors.length; i++)
				if (flavor.equals(flavors[i])) return true;
			return false;
		}
	}

	//TODO Make this shit work with negative values
	public static void main(String[] args) {
		fig = new FalconDankPlot(3);
	}
}